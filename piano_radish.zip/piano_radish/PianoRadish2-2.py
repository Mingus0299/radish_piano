import pygame
import random

#initialization of pygame
pygame.init()

#screen display
screen = pygame.display.set_mode((340,700))

#icon
pygame.display.set_caption("2PIANOsRADISH")
icon = pygame.image.load("assets/visuals/grand-piano.png")
pygame.display.set_icon(icon)

#background
background = pygame.image.load('assets/visuals/ornamental.jpg')

#number of tiles
n = 99999

#tiles
blueImg = pygame.image.load('assets/visuals/rectangle.png')
tileImg1 = blueImg
tileImg2 = blueImg
tileImg3 = blueImg
tileImg4 = blueImg
tileImg5 = blueImg

tileY_change = 5

blackImg = pygame.image.load('assets/visuals/blank.png')

#border
border2 = pygame.Rect(0, 565, 340, 10)

'''
a = opponent_1 ; b = opponent_2
TILE X:
tileXa:
 - Xa1
 - Xa2
 - Xa3
 - Xa4
 ...

tileXb:
 - Xb1
 - Xb2
 - Xb3
 - Xb4
 ...



TILE Y:
tileYa:
 - Ya1
 - Ya2
 - Ya3
 - Ya4
 ...

tileYb:
 - Yb1
 - Yb2
 - Yb3
 - Yb4
 ...
 

'''
Ya1 = -180
Xa1 = 0
Ya2 = -360
Xa2 = -900
Ya3 = -720
Xa3 = -900
Ya4 = -10000
Xa4 = -10000
Ya5 = -10000
Xa5 = -10000



lst_tiles = []
lst_order = []

for i in range(n):
    lst_tiles.append(random.randint(1,4))
for i in range(len(lst_tiles)-1):
    if lst_tiles[i] == 1:
        lst_tiles[i] = 0
        
    elif lst_tiles[i] == 2:
        lst_tiles[i] = 70

    elif lst_tiles[i] == 3:
        lst_tiles[i] = 140

    elif lst_tiles[i] == 4:
        lst_tiles[i] = 210


def Y_tiles(tileY):
    tileY = tileY + tileY_change

def tiles(x,y, tileImg):
    screen.blit(tileImg, (x, y))

running = True
clock = pygame.time.Clock()

while running:
    clock.tick(60)
    screen.fill((0, 0, 0))
    
    screen.blit(background, (0, 0))
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    if Ya1 == 0:
        Ya2 = -230
        Xa2 = lst_tiles.pop(0)
        tileImg2 = blueImg
        
    if Ya2 == 0:
        Ya3 = -230
        Xa3 = lst_tiles.pop(0)
        tileImg3 = blueImg
        
    if Ya3 == 0:
        Ya4 = -230
        Xa4 = lst_tiles.pop(0)
        tileImg4 = blueImg
        
    if Ya4 == 0:
        Ya5 = -230
        Xa5 = lst_tiles.pop(0)
        tileImg5 = blueImg
        
    if Ya5 == 0:
        Ya1 = -230
        Xa1 = lst_tiles.pop(0)
        tileImg1 = blueImg
    
    if event.type == pygame.KEYDOWN:
        
        if Ya1 >= 500 and Ya1 <= 565:
            if Xa1 == 0:
                if event.key == pygame.K_a:
                    tileImg1 = blackImg
                    
            elif Xa1 == 70:
                if event.key == pygame.K_s:
                    tileImg1 = blackImg
                    
            elif Xa1 == 140:
                if event.key == pygame.K_d:
                    tileImg1 = blackImg
                    
            elif Xa1 == 210:
                if event.key == pygame.K_f:
                    tileImg1 = blackImg
                
        if Ya2 >= 437 and Ya2 <= 565:
            if Xa2 == 0:
                if event.key == pygame.K_a:
                    tileImg2 = blackImg
                    
            elif Xa2 == 70:
                if event.key == pygame.K_s:
                    tileImg2 = blackImg
                    
            elif Xa2 == 140:
                if event.key == pygame.K_d:
                    tileImg2 = blackImg
                    
            elif Xa2 == 210:
                if event.key == pygame.K_f:
                    tileImg2 = blackImg
                
        if Ya3 >= 437 and Ya3 <= 565:
            if Xa3 == 0:
                if event.key == pygame.K_a:
                    tileImg3 = blackImg
                    
            elif Xa3 == 70:
                if event.key == pygame.K_s:
                    tileImg3 = blackImg
                    
            elif Xa3 == 140:
                if event.key == pygame.K_d:
                    tileImg3 = blackImg
                    
            elif Xa3 == 210:
                if event.key == pygame.K_f:
                    tileImg3 = blackImg
                
        if Ya4 >= 437 and Ya4 <= 565:
            if Xa4 == 0:
                if event.key == pygame.K_a:
                    tileImg4 = blackImg
                    
            elif Xa4 == 70:
                if event.key == pygame.K_s:
                    tileImg4 = blackImg
                    
            elif Xa4 == 140:
                if event.key == pygame.K_d:
                    tileImg4 = blackImg
                    
            elif Xa4 == 210:
                if event.key == pygame.K_f:
                    tileImg4 = blackImg
                
        if Ya5 >= 437 and Ya5 <= 565:
            if Xa5 == 0:
                if event.key == pygame.K_a:
                    tileImg5 = blackImg
                    
            elif Xa5 == 70:
                if event.key == pygame.K_s:
                    tileImg5 = blackImg
                    
            elif Xa5 == 140:
                if event.key == pygame.K_d:
                    tileImg5 = blackImg
                    
            elif Xa5 == 210:
                if event.key == pygame.K_f:
                    tileImg5 = blackImg
                    
    if event.type == pygame.KEYUP:
        if Ya1 >= 437 and Ya1 <= 565:
            if Xa1 == 0:
                if event.key == pygame.K_a:
                    tileImg1 = blackImg
                    
            elif Xa1 == 70:
                if event.key == pygame.K_s:
                    tileImg1 = blackImg
                    
            elif Xa1 == 140:
                if event.key == pygame.K_d:
                    tileImg1 = blackImg
                    
            elif Xa1 == 210:
                if event.key == pygame.K_f:
                    tileImg1 = blackImg
                
        if Ya2 >= 437 and Ya2 <= 565:
            if Xa2 == 0:
                if event.key == pygame.K_a:
                    tileImg2 = blackImg
                    
            elif Xa2 == 70:
                if event.key == pygame.K_s:
                    tileImg2 = blackImg
                    
            elif Xa2 == 140:
                if event.key == pygame.K_d:
                    tileImg2 = blackImg
                    
            elif Xa2 == 210:
                if event.key == pygame.K_f:
                    tileImg2 = blackImg
                
        if Ya3 >= 437 and Ya3 <= 565:
            if Xa3 == 0:
                if event.key == pygame.K_a:
                    tileImg3 = blackImg
                    
            elif Xa3 == 70:
                if event.key == pygame.K_s:
                    tileImg3 = blackImg
                    
            elif Xa3 == 140:
                if event.key == pygame.K_d:
                    tileImg3 = blackImg
                    
            elif Xa3 == 210:
                if event.key == pygame.K_f:
                    tileImg3 = blackImg
                
        if Ya4 >= 437 and Ya4 <= 565:
            if Xa4 == 0:
                if event.key == pygame.K_a:
                    tileImg4 = blackImg
                    
            elif Xa4 == 70:
                if event.key == pygame.K_s:
                    tileImg4 = blackImg
                    
            elif Xa4 == 140:
                if event.key == pygame.K_d:
                    tileImg4 = blackImg
                    
            elif Xa4 == 210:
                if event.key == pygame.K_f:
                    tileImg4 = blackImg
                
        if Ya5 >= 437 and Ya5 <= 565:
            if Xa5 == 0:
                if event.key == pygame.K_a:
                    tileImg5 = blackImg
                    
            elif Xa5 == 70:
                if event.key == pygame.K_s:
                    tileImg5 = blackImg
                    
            elif Xa5 == 140:
                if event.key == pygame.K_d:
                    tileImg5 = blackImg
                    
            elif Xa5 == 210:
                if event.key == pygame.K_f:
                    tileImg5 = blackImg
    
    
    Ya1 = Ya1 + tileY_change
    Ya2 = Ya2 + tileY_change
    Ya3 = Ya3 + tileY_change
    Ya4 = Ya4 + tileY_change
    Ya5 = Ya5 + tileY_change
    
    
    tiles(Xa1, Ya1, tileImg1)
    tiles(Xa2, Ya2, tileImg2)
    tiles(Xa3, Ya3, tileImg3)
    tiles(Xa4, Ya4, tileImg4)
    tiles(Xa5, Ya5, tileImg5)

    pygame.draw.rect(screen, (50, 30, 50), border2)
    
    pygame.display.update()