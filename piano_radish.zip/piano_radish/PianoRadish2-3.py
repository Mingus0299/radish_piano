import pygame
import random
from flask import Flask #web application

#initialization of pygame
pygame.init()

#screen display
screen = pygame.display.set_mode((340,700))
X = 340
Y = 700
display_surface = pygame.display.set_mode((X, Y))

#icon
pygame.display.set_caption("2PIANOsRADISH")
icon = pygame.image.load("assets/visuals/grand-piano.png")
pygame.display.set_icon(icon)

#background
background = pygame.image.load('assets/visuals/ornamental.jpg')

#number of tiles
n = 999999

#tiles
tileImg = pygame.image.load('assets/visuals/rectangle.png')
tileY_change = 3

#colors
white = (255, 255, 255)
green = (0, 255, 0)
blue = (0, 0, 128)

#text
font = pygame.font.Font('freesansbold.ttf', 32)
text = font.render('GAME OVER!!!', True, white)
textRect = text.get_rect()
textRect.center = (X // 2, Y // 2)

#sound
piano_C = pygame.mixer.Sound('assets/sound/piano-mp3_C4.mp3')
piano_D = pygame.mixer.Sound('assets/sound/piano-mp3_D4.mp3')
piano_E = pygame.mixer.Sound('assets/sound/piano-mp3_E4.mp3')
piano_F = pygame.mixer.Sound('assets/sound/piano-mp3_F4.mp3')


'''
a = opponent_1 ; b = opponent_2
TILE X:
tileXa:
 - Xa1
 - Xa2
 - Xa3
 - Xa4
 ...

tileXb:
 - Xb1
 - Xb2
 - Xb3
 - Xb4
 ...



TILE Y:
tileYa:
 - Ya1
 - Ya2
 - Ya3
 - Ya4
 ...

tileYb:
 - Yb1
 - Yb2
 - Yb3
 - Yb4
 ...
 

'''
Ya1 = -180
Xa1 = 0
Ya2 = -360
Xa2 = -900
Ya3 = -720
Xa3 = -900
Ya4 = -10000
Xa4 = -10000
Ya5 = -10000
Xa5 = -10000

lst_tiles = []

BOTTOM_POS = 700
KEY_PRESSED = False #correct key pressed at y = 650 to 700

for i in range(n):
    lst_tiles.append(random.randint(1,4))
for i in range(len(lst_tiles)-1):
    if lst_tiles[i] == 1:
        lst_tiles[i] = 0
    elif lst_tiles[i] == 2:
        lst_tiles[i] = 70
    elif lst_tiles[i] == 3:
        lst_tiles[i] = 140
    elif lst_tiles[i] == 4:
        lst_tiles[i] = 210
        

def Y_tiles(tileY):
    tileY = tileY + tileY_change

def tiles(x,y):
    screen.blit(tileImg, (x, y))

running = True
clock = pygame.time.Clock()

while running:
    clock.tick(144) #FPS
    screen.fill((0, 0, 0))
    
    screen.blit(background, (0, 0))
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    if Ya1 == 0:
        Ya2 = -180
        Xa2 = lst_tiles.pop(0)
    if Ya2 == 0:
        Ya3 = -180
        Xa3 = lst_tiles.pop(0)
    if Ya3 == 0:
        Ya4 = -180
        Xa4 = lst_tiles.pop(0)
    if Ya4 == 0:
        Ya5 = -180
        Xa5 = lst_tiles.pop(0)
    if Ya5 == 0:
        Ya1 = -180
        Xa1 = lst_tiles.pop(0)

    
    
    Ya1 = Ya1 + tileY_change
    Ya2 = Ya2 + tileY_change
    Ya3 = Ya3 + tileY_change
    Ya4 = Ya4 + tileY_change
    Ya5 = Ya5 + tileY_change


    
    tiles(Xa1, Ya1)
    tiles(Xa2, Ya2)
    tiles(Xa3, Ya3)
    tiles(Xa4, Ya4)
    tiles(Xa5, Ya5)


    
    pygame.display.update()