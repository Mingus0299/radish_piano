import pygame
import random

#initialization of pygame
pygame.init()

#screen display
screen = pygame.display.set_mode((900,700))

#icon
pygame.display.set_caption("2PIANOsRADISH")
icon = pygame.image.load("grand-piano.png")
pygame.display.set_icon(icon)

#background
background = pygame.image.load('ornamental.jpg')

#number of tiles
n = 999999

#tiles
tileImg = pygame.image.load('rectangle.png')
#lst_Xa = [0, 100, 200, 300]
#lst_Xb = [450, 550, 650, 750]
tileY_change = 10

'''
a = opponent_1 ; b = opponent_2
TILE X:
tileXa:
 - Xa1
 - Xa2
 - Xa3
 - Xa4
 ...

tileXb:
 - Xb1
 - Xb2
 - Xb3
 - Xb4
 ...



TILE Y:
tileYa:
 - Ya1
 - Ya2
 - Ya3
 - Ya4
 ...

tileYb:
 - Yb1
 - Yb2
 - Yb3
 - Yb4
 ...
 

'''
Ya1 = -180
Xa1 = 0
Ya2 = -360
Xa2 = -900
Ya3 = -720
Xa3 = -900
Ya4 = -10000
Xa4 = -10000



lst_tiles = []

for i in range(n):
    lst_tiles.append(random.randint(1,4))
for i in range(len(lst_tiles)-1):
    if lst_tiles[i] == 1:
        lst_tiles[i] = 0
    elif lst_tiles[i] == 2:
        lst_tiles[i] = 100
    elif lst_tiles[i] == 3:
        lst_tiles[i] = 300
    elif lst_tiles[i] == 4:
        lst_tiles[i] = 400
        

def Y_tiles(tileY):
    tileY = tileY + tileY_change

def tiles(x,y):
    screen.blit(tileImg, (x, y))

running = True
clock = pygame.time.Clock()

while running:
    clock.tick(60)
    screen.fill((0, 0, 0))
    
    screen.blit(background, (0, 0))
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    if Ya1 == 0:
        Ya2 = -180
        Xa2 = lst_tiles.pop(0)
    if Ya2 == 0:
        Ya3 = -180
        Xa3 = lst_tiles.pop(0)
    if Ya3 == 0:
        Ya4 = -180
        Xa4 = lst_tiles.pop(0)
    if Ya4 == 0:
        Ya5 = -180
        Xa5 = lst_tiles.pop(0)
    
    
    
    Ya1 = Ya1 + tileY_change
    Ya2 = Ya2 + tileY_change
    Ya3 = Ya3 + tileY_change
    Ya4 = Ya4 + tileY_change


    
    tiles(Xa1, Ya1)
    tiles(Xa2, Ya2)
    tiles(Xa3, Ya3)
    tiles(Xa4, Ya4)


    
    pygame.display.update()